﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace MMTRecentOrdersCustomer
{
    public class RecentCustomerOrder
    {
        [Key]
        public string CustomerId { get; set; }
        public string User { get; set; }
        public string FirstName { get; set; }
		public string LastName { get; set; }
		public string DeliveryAddress { get; set; }

		public Orders Orders { get; set; }
	}
}


