﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace MMTRecentOrdersService
{
    public interface IHttpUtilityService
    {
        Task<string> Download(string url);
        string GetCustomerDetailsUrl(string email);

    }
}
