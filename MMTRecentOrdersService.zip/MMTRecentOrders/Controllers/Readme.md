﻿I did not have enough time refactore the code, remove unwanted fields and the order of the fields to meet
the requirements.