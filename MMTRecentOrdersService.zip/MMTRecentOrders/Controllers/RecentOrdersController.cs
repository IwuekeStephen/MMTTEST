﻿using Microsoft.AspNetCore.Mvc;
using MMTRecentOrdersCustomer;
using MMTRecentOrdersRepository;
using RecentCustomerOrderViewModelBuilder;
using System.Collections.Generic;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace MMTRecentOrders.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RecentOrdersController : ControllerBase
    {
       
        private readonly IRecentOrdersRepo _recentOrdersRepo;
        private readonly IRecentOrderViewModelBuilder _recentOrderViewModelBuilder;
        public RecentOrdersController(IRecentOrderViewModelBuilder recentOrderViewModelBuilder,
            IRecentOrdersRepo recentOrdersRepo)
        {
           _recentOrderViewModelBuilder = recentOrderViewModelBuilder;
            _recentOrdersRepo = recentOrdersRepo;
        }
        // GET: api/<RecentOrders>
        [HttpGet]
        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2" };
        }

        // GET api/<RecentOrders>/5
        [HttpGet("{id}")]
        public string Get(int id)
        {
            return "value";
        }

        // POST api/<RecentOrders>
        [HttpPost]
        public ActionResult<RecentCustomerOrderViewModel> Post(Customer customer)
        {
            var recentCustomerOrderViewModel = _recentOrderViewModelBuilder.Build(customer);

             return recentCustomerOrderViewModel;
         }
        // PUT api/<RecentOrders>/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE api/<RecentOrders>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
